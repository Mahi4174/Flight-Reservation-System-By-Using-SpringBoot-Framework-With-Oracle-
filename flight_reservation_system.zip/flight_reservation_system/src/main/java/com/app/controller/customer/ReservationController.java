package com.app.controller.customer;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.entities.backend.GeoLocation;
import com.app.entities.customers.CustomerFlightReservation;
import com.app.repository.CustomerFlightRepository;
import com.app.repository.GeoLocationRepository;

@Controller
public class ReservationController {
	@Autowired
	CustomerFlightRepository repo;
	
	@Autowired
	GeoLocationRepository geoLocationRepo;

	@RequestMapping(path = "/reservation", method = RequestMethod.POST)
	public String reservation(@RequestParam("user_id") Integer user_id, 
			@RequestParam("source") String source,
			@RequestParam("destination") String destination, 
			@RequestParam("departureDate") String departureDate,
			@RequestParam("seats") Integer seats, 
			@RequestParam("reservationType") String reservationType
			) {
		CustomerFlightReservation cfr = new CustomerFlightReservation(user_id, source, destination, 
				departureDate,seats, reservationType);
		repo.save(cfr);
		return "registrationSuccess";
	}
	
	@GetMapping(path = "/ticketFare")
	@ResponseBody
	public Double reservation( 
			@RequestParam("source") String source,
			@RequestParam("destination") String destination,
			@RequestParam("reservationType") String reservationType) {
		
		System.out.println("Source = "+source);
		System.out.println("Destination = "+destination);
		
		
		double AVERAGE_RADIUS_OF_EARTH_KM = 6371;
		GeoLocation sc=geoLocationRepo.findById(source).get();
		GeoLocation dest=geoLocationRepo.findById(destination).get();
		System.out.println(sc);
		System.out.println(dest);
		
		double userLat=sc.getLatitude(); 
		double userLng=sc.getLongitude();
		double venueLat=dest.getLatitude();
		double venueLng=dest.getLongitude();
		double latDistance = Math.toRadians(userLat - venueLat);
		double lngDistance = Math.toRadians(userLng - venueLng);
		double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
				      + Math.cos(Math.toRadians(userLat)) * Math.cos(Math.toRadians(venueLat))
				      * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);

		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		double distance=(Math.round(AVERAGE_RADIUS_OF_EARTH_KM * c));
		System.out.println("Travel Distance  =  "+distance );

		String seatType=reservationType;
		double seatFare=0; 
		double farePerKm=5;
		double travelDuration=(double)distance/800;
		System.out.println("Travel Duration  =  "+travelDuration );
		switch(seatType){
			case "economy":
				seatFare=250;
				break;
			case "business":
				seatFare=500;
				break;
		}
		double ticketFare=(distance*farePerKm) + ( seatFare*travelDuration);
		System.out.print(ticketFare);
		return ticketFare;
	}
	@RequestMapping(path = "/geoLocation/all", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<GeoLocation> getAllCustomers() {
		return (ArrayList<GeoLocation>) geoLocationRepo.findAll();
	}

}
