package com.app.controller.administrator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.app.entities.customers.PassengerDetails;
import com.app.repository.CustomerProfileRepository;
import com.app.repository.PassengerDetailsRepository;

@Controller
public class PassengerDetailsController {
	
	@Autowired
	PassengerDetailsRepository passRepo;
	
	@Autowired
	CustomerProfileRepository customerRepo;
	
	//view
		@GetMapping("/viewAllPassengers")
		public String viewPasseng(Model model) {
			List<PassengerDetails> passengers = (ArrayList<PassengerDetails>) passRepo.findAll();
			model.addAttribute("passengers", passengers);
			
			return "allPassengers";
		}

}
