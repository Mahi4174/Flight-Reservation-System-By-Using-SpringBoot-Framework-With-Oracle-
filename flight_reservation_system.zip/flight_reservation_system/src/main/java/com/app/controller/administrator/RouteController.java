package com.app.controller.administrator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entities.backend.Route;
import com.app.repository.RouteRepository;

@Controller
public class RouteController {
	//Route CRUD
		@Autowired
		RouteRepository routeRepo;
		
		//Add & Modify
		@GetMapping(path="/insertRoute")
		public String insertFlight(@RequestParam("route_Id") Integer route_Id,
				@RequestParam("source") String source,
				@RequestParam("destination") String destination,
				@RequestParam("distance") Integer distance,
				@RequestParam("duration") String duration,
				@RequestParam("km_cost") Integer km_cost
				) {
			Route route=new Route(route_Id,source,destination,distance,duration,km_cost);
			routeRepo.save(route);	
			return "success";
		}

		//view
		@GetMapping("/viewAllRoutes")
		public String viewRoutes(Model model) {
			List<Route> routes = (ArrayList<Route>) routeRepo.findAll();
			model.addAttribute("routes", routes);
			return "allRoutes";
		}
		
		//delete
		@GetMapping(path = "/deleteRoute")
		public String deleteRoute(@RequestParam("route_Id") Integer route_Id) {
			routeRepo.deleteById(route_Id);
			return "success";
		}

}
