package com.app.backenddata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.entities.backend.Flight;
import com.app.repository.FlightRepository;

@Controller
public class FlightDataBase {
	@Autowired
	FlightRepository flightRepo;

	@GetMapping("/FlightData")
	@ResponseBody
	public String GeoDataInsertion(	) {
		Flight flight=new Flight("indigo", 200,100,100,250,500);
		flightRepo.save(flight);
		flight=new Flight("airIndia", 200,100,100,250,500);
		flightRepo.save(flight);
		flight=new Flight("airAsia", 200,100,100,250,500);
		flightRepo.save(flight);
		flight=new Flight("spiceJet", 200,100,100,250,500);
		flightRepo.save(flight);
		flight=new Flight("vistara", 200,100,100,250,500);
		flightRepo.save(flight);
	return "Flight Data Inserted Successfully";
	}
}
