package com.app.entities.administrator;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "administrator_credentials")
public class AdministratorCredentials {
	private String user_type;
	@Id
	// @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer administrator_id;
	private String password;
	// private String login_status;

	public AdministratorCredentials() {

	}

	public AdministratorCredentials(String user_type, Integer administrator_id, String password) {
		super();
		this.user_type = user_type;
		this.administrator_id = administrator_id;
		this.password = password;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public Integer getAdministrator_id() {
		return administrator_id;
	}

	public void setAdministrator_id(Integer administrator_id) {
		this.administrator_id = administrator_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "AdministratorCredentials [user_type=" + user_type + ", administrator_id=" + administrator_id
				+ ", password=" + password + "]";
	}
}
