package com.app.entities.customers;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "passenger_details")
public class PassengerDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer pass_id;
	private String firstName;
	private String lastName;
	private String journey_date;
	private String source;
	private String destination;
	private String seat_type;
	private Integer seats;
	private String payment_mode;

	public PassengerDetails() {
	}

	public PassengerDetails(Integer pass_id, String firstName, String lastName, String journey_date, String source,
			String destination, String seat_type, Integer seats, String payment_mode) {
		this.pass_id = pass_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.journey_date = journey_date;
		this.source = source;
		this.destination = destination;
		this.seat_type = seat_type;
		this.seats = seats;
		this.payment_mode = payment_mode;
	}

	public PassengerDetails(String firstName, String lastName, String journey_date, String source, String destination,
			String seat_type, Integer seats, String payment_mode) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.journey_date = journey_date;
		this.source = source;
		this.destination = destination;
		this.seat_type = seat_type;
		this.seats = seats;
		this.payment_mode = payment_mode;
	}

	public Integer getPass_id() {
		return pass_id;
	}

	public void setPass_id(Integer pass_id) {
		this.pass_id = pass_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getJourney_date() {
		return journey_date;
	}

	public void setJourney_date(String journey_date) {
		this.journey_date = journey_date;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getSeat_type() {
		return seat_type;
	}

	public void setSeat_type(String seat_type) {
		this.seat_type = seat_type;
	}

	public Integer getSeats() {
		return seats;
	}

	public void setSeats(Integer seats) {
		this.seats = seats;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	@Override
	public String toString() {
		return "PassengerDetails [pass_id=" + pass_id + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", journey_date=" + journey_date + ", source=" + source + ", destination=" + destination
				+ ", seat_type=" + seat_type + ", seats=" + seats + ", payment_mode=" + payment_mode + "]";
	}
}
