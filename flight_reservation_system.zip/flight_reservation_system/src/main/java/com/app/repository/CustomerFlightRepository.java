package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.customers.CustomerFlightReservation;

public interface CustomerFlightRepository extends CrudRepository<CustomerFlightReservation, Integer> {

}
