package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.administrator.AdministratorCredentials;

public interface AdministratorCredentialsRepository extends CrudRepository<AdministratorCredentials, Integer> {

}
