package com.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.backend.Schedule;

public interface ScheduleRepository extends CrudRepository<Schedule, Integer> {
	List<Schedule> findBysource(String source);
	List<Schedule> findBydestination(String destination);
}
