package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.administrator.AdministratorProfile;

public interface AdministratorProfileRepository extends CrudRepository<AdministratorProfile, Integer> {

}
