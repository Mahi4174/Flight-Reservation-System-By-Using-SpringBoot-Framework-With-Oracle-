package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.customers.CustomerCredentials;

public interface CustomerCredentialsRepository extends CrudRepository<CustomerCredentials, Integer> {

}
