package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.customers.PassengerDetails;

public interface  PassengerDetailsRepository extends CrudRepository<PassengerDetails, Integer> {

}
